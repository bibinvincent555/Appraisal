from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from .models import CustomUser, Hospital, Bus, Emergency, EmergencyLog
from .forms import EmergencyReportForm, UserRegistrationForm, HospitalForm, BusForm, UserAssignmentForm
import math

# Role Checks
def is_admin(user):
    return user.is_authenticated and user.role == CustomUser.ADMIN

def is_bus_staff(user):
    return user.is_authenticated and user.role == CustomUser.BUS_STAFF

def is_hospital_staff(user):
    return user.is_authenticated and user.role == CustomUser.HOSPITAL_STAFF

def calculate_distance(lat1, lon1, lat2, lon2):
    R = 6371.0 # Earth radius in km
    lat1_rad = math.radians(lat1)
    lon1_rad = math.radians(lon1)
    lat2_rad = math.radians(lat2)
    lon2_rad = math.radians(lon2)
    
    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad
    
    a = math.sin(dlat / 2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

def find_nearest_hospital(bus_lat, bus_lng, emergency_type=None, exclude_hospitals=None):
    active_hospitals = Hospital.objects.filter(is_active=True, is_enabled=True, is_at_full_capacity=False)
    if exclude_hospitals:
        active_hospitals = active_hospitals.exclude(id__in=[h.id for h in exclude_hospitals])
        
    if not active_hospitals.exists():
        return None
    nearest = None
    min_dist = float('inf')
    for hospital in active_hospitals:
        dist = calculate_distance(bus_lat, bus_lng, hospital.latitude, hospital.longitude)
        if dist < min_dist:
            min_dist = dist
            nearest = hospital
    return nearest

# Authentication
def login_view(request):
    if request.method == 'POST':
        u = request.POST.get('username')
        p = request.POST.get('password')
        user = authenticate(username=u, password=p)
        if user:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid credentials')
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

def register_view(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Account created successfully. Please login.')
            return redirect('login')
    else:
        form = UserRegistrationForm()
    return render(request, 'register.html', {'form': form})

# Dashboards
@login_required
def dashboard(request):
    if request.user.role == CustomUser.ADMIN:
        return redirect('admin_dashboard')
    elif request.user.role == CustomUser.BUS_STAFF:
        return redirect('bus_dashboard')
    else:
        return redirect('hospital_dashboard')

@login_required
@user_passes_test(is_admin)
def admin_dashboard(request):
    emergencies = Emergency.objects.all().order_by('-created_at')
    stats = {
        'total_e': emergencies.count(),
        'hospitals': Hospital.objects.count(),
        'buses': Bus.objects.count(),
        'users': CustomUser.objects.count()
    }
    return render(request, 'admin/dashboard.html', {'emergencies': emergencies, 'stats': stats})

@login_required
@user_passes_test(is_bus_staff)
def bus_dashboard(request):
    if not request.user.assigned_bus:
        messages.warning(request, "No bus assigned to your account. Please wait for Admin verification.")
        return render(request, 'bus_dashboard.html', {'emergencies': [], 'stats': {}})
        
    emergencies = Emergency.objects.filter(bus=request.user.assigned_bus).order_by('-created_at')
    stats = {
        'total': emergencies.count(),
        'pending': emergencies.exclude(status='closed').count(),
        'resolved': emergencies.filter(status='closed').count()
    }
    return render(request, 'bus_dashboard.html', {'emergencies': emergencies, 'stats': stats})

@login_required
@user_passes_test(is_hospital_staff)
def hospital_dashboard(request):
    hospital = request.user.assigned_hospital
    if not hospital:
        messages.warning(request, "No hospital assigned to your account. Contact Admin.")
        return render(request, 'hospital_dashboard.html', {'emergencies': [], 'stats': {}})
        
    assigned = Emergency.objects.filter(hospital_notified=hospital).order_by('-created_at')
    stats = {
        'incoming': assigned.filter(status__in=['notified', 'accepted', 'attended', 'received']).count(),
        'awaiting': assigned.filter(status='notified').count(),
        'completed': assigned.filter(status='closed').count()
    }
    return render(request, 'hospital_dashboard.html', {'emergencies': assigned, 'stats': stats, 'hospital': hospital})

# Admin CRUD
@login_required
@user_passes_test(is_admin)
def manage_hospitals(request):
    hospitals = Hospital.objects.all()
    return render(request, 'admin/hospitals.html', {'hospitals': hospitals})

@login_required
@user_passes_test(is_admin)
def add_hospital(request):
    if request.method == 'POST':
        form = HospitalForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('manage_hospitals')
    else: form = HospitalForm()
    return render(request, 'admin/form.html', {'form': form, 'title': 'Add Hospital'})

@login_required
@user_passes_test(is_admin)
def manage_buses(request):
    buses = Bus.objects.all()
    return render(request, 'admin/buses.html', {'buses': buses})

@login_required
@user_passes_test(is_admin)
def add_bus(request):
    if request.method == 'POST':
        form = BusForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('manage_buses')
    else: form = BusForm()
    return render(request, 'admin/form.html', {'form': form, 'title': 'Add Bus'})

@login_required
@user_passes_test(is_admin)
def manage_users(request):
    users = CustomUser.objects.exclude(role=CustomUser.ADMIN).order_by('-date_joined')
    return render(request, 'admin/users.html', {'users': users})

@login_required
@user_passes_test(is_admin)
def edit_user(request, pk):
    user_obj = get_object_or_404(CustomUser, pk=pk)
    if request.method == 'POST':
        form = UserAssignmentForm(request.POST, instance=user_obj)
        if form.is_valid():
            form.save()
            messages.success(request, f'User {user_obj.username} updated.')
            return redirect('manage_users')
    else:
        form = UserAssignmentForm(instance=user_obj)
    return render(request, 'admin/form.html', {'form': form, 'title': f'Edit User: {user_obj.username}'})

# Emergency Flow
@login_required
@user_passes_test(is_bus_staff)
def report_emergency(request):
    if request.method == 'POST':
        form = EmergencyReportForm(request.POST)
        if form.is_valid():
            emergency = form.save(commit=False)
            # Auto-assign bus if staff has one
            if request.user.assigned_bus:
                emergency.bus = request.user.assigned_bus
            
            nearest = find_nearest_hospital(emergency.latitude, emergency.longitude, emergency.emergency_type)
            if nearest:
                emergency.hospital_notified = nearest
                emergency.status = 'notified'
                emergency.save()
                
                EmergencyLog.objects.create(
                    emergency=emergency, action='Incident Reported', performed_by=request.user,
                    details=f'Manual alert initiated. Routing to {nearest.name}.'
                )
                
                messages.success(request, f'Alert sent to {nearest.name}.')
                return redirect('emergency_detail', pk=emergency.pk)
            else:
                messages.error(request, 'No active hospitals found in vicinity.')
    else:
        # Pre-fill bus if available
        initial = {}
        if request.user.assigned_bus:
            initial['bus'] = request.user.assigned_bus
        form = EmergencyReportForm(initial=initial)
    return render(request, 'report_emergency.html', {'form': form})

@login_required
def emergency_detail(request, pk):
    emergency = get_object_or_404(Emergency, pk=pk)
    logs = emergency.logs.all().order_by('-timestamp')
    return render(request, 'emergency_detail.html', {'emergency': emergency, 'logs': logs})

# Hospital Actions
@login_required
@user_passes_test(is_hospital_staff)
def accept_emergency(request, pk):
    emergency = get_object_or_404(Emergency, pk=pk)
    emergency.status = 'accepted'
    emergency.accepted_at = timezone.now()
    emergency.save()
    EmergencyLog.objects.create(emergency=emergency, action='Emergency Accepted', performed_by=request.user, details='Hospital confirmed readiness.')
    return redirect('emergency_detail', pk=pk)

@login_required
@user_passes_test(is_hospital_staff)
def reject_emergency(request, pk):
    emergency = get_object_or_404(Emergency, pk=pk)
    original_hospital = emergency.hospital_notified
    emergency.status = 'rejected'
    emergency.save()
    emergency.rejected_by.add(original_hospital)
    
    EmergencyLog.objects.create(emergency=emergency, action='Emergency Rejected', performed_by=request.user, details=f'Rejected by {original_hospital.name}. Re-routing...')
    
    # Try re-routing
    rejected_hospitals = emergency.rejected_by.all()
    nearest = find_nearest_hospital(emergency.latitude, emergency.longitude, emergency.emergency_type, exclude_hospitals=rejected_hospitals)
            
    if nearest:
        emergency.hospital_notified = nearest
        emergency.status = 'notified'
        emergency.save()
        messages.info(request, f"Request rejected. Re-routed to {nearest.name}.")
    else:
        messages.error(request, "Request rejected and no other hospitals found.")
        
    return redirect('hospital_dashboard')

@login_required
@user_passes_test(is_hospital_staff)
def update_status(request, pk, status):
    emergency = get_object_or_404(Emergency, pk=pk)
    if status in dict(Emergency.STATUS_CHOICES):
        emergency.status = status
        if status == 'attended': emergency.attended_at = timezone.now()
        if status == 'received': emergency.received_at = timezone.now()
        if status == 'closed': emergency.closed_at = timezone.now()
        emergency.save()
        
        action_name = dict(Emergency.STATUS_CHOICES)[status]
        EmergencyLog.objects.create(emergency=emergency, action=f'Status Updated: {action_name}', performed_by=request.user)
        messages.success(request, f'Status updated to {action_name}.')
    return redirect('emergency_detail', pk=pk)

@login_required
@user_passes_test(is_bus_staff)
def update_condition(request, pk):
    emergency = get_object_or_404(Emergency, pk=pk)
    if request.method == 'POST':
        update = request.POST.get('condition_update')
        
        timestamp = timezone.localtime(timezone.now()).strftime("%Y-%m-%d %H:%M:%S")
        formatted_update = f"[{timestamp}] {update}"
        if emergency.condition_update:
            emergency.condition_update += f"\n{formatted_update}"
        else:
            emergency.condition_update = formatted_update
            
        emergency.save()
        EmergencyLog.objects.create(emergency=emergency, action='Condition Updated', performed_by=request.user, details=f'Bus Staff reported: {update}')
        messages.success(request, 'Passenger condition updated. Hospital team notified.')
    return redirect('emergency_detail', pk=pk)
