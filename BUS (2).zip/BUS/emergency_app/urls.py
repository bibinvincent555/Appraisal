from django.urls import path
from . import views

urlpatterns = [
    # Auth
    path('', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    
    # Dashboards
    path('dashboard/admin/', views.admin_dashboard, name='admin_dashboard'),
    path('dashboard/bus/', views.bus_dashboard, name='bus_dashboard'),
    path('dashboard/hospital/', views.hospital_dashboard, name='hospital_dashboard'),
    
    # Admin CRUD - Hospitals
    path('manage/hospitals/', views.manage_hospitals, name='manage_hospitals'),
    path('manage/hospitals/add/', views.add_hospital, name='add_hospital'),
    
    # Admin CRUD - Buses
    path('manage/buses/', views.manage_buses, name='manage_buses'),
    path('manage/buses/add/', views.add_bus, name='add_bus'),
    
    # Admin CRUD - Users
    path('manage/users/', views.manage_users, name='manage_users'),
    path('manage/users/<int:pk>/edit/', views.edit_user, name='edit_user'),
    
    # Emergency Operations
    path('report/', views.report_emergency, name='report_emergency'),
    path('emergency/<int:pk>/', views.emergency_detail, name='emergency_detail'),
    
    # Hospital Interactions
    path('emergency/<int:pk>/accept/', views.accept_emergency, name='accept_emergency'),
    path('emergency/<int:pk>/reject/', views.reject_emergency, name='reject_emergency'),
    path('emergency/<int:pk>/update-status/<str:status>/', views.update_status, name='update_status'),
    path('emergency/<int:pk>/update-condition/', views.update_condition, name='update_condition'),
]
