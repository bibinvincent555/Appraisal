from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator, MaxValueValidator

class Hospital(models.Model):
    name = models.CharField(max_length=200)
    address = models.TextField()
    contact_number = models.CharField(max_length=20, null=True, blank=True)
    latitude = models.FloatField()
    longitude = models.FloatField()
    email = models.EmailField()
    is_active = models.BooleanField(default=True) # Used by system to route
    is_enabled = models.BooleanField(default=True) # Admin toggle
    
    # Capacity management
    emergency_capacity = models.IntegerField(default=10)
    specialties = models.CharField(max_length=500, default='General Medicine, Trauma')
    is_at_full_capacity = models.BooleanField(default=False)
    
    def __str__(self):
        return self.name

class Bus(models.Model):
    bus_number = models.CharField(max_length=50, unique=True)
    route_name = models.CharField(max_length=100)
    driver_name = models.CharField(max_length=100)
    conductor_name = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"Bus {self.bus_number} - {self.route_name}"

class CustomUser(AbstractUser):
    ADMIN = 'admin'
    BUS_STAFF = 'bus_staff'
    HOSPITAL_STAFF = 'hospital_staff'
    
    ROLE_CHOICES = [
        (ADMIN, 'System Administrator'),
        (BUS_STAFF, 'Bus Staff (Driver/Conductor)'),
        (HOSPITAL_STAFF, 'Hospital Staff'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=BUS_STAFF)
    
    # Relationships for role-specific context
    assigned_hospital = models.ForeignKey(Hospital, on_delete=models.SET_NULL, null=True, blank=True, related_name='staff')
    assigned_bus = models.ForeignKey(Bus, on_delete=models.SET_NULL, null=True, blank=True, related_name='staff')
    contact_number = models.CharField(max_length=20, null=True, blank=True)

    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"

class Emergency(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending - Searching'),
        ('notified', 'Hospital Notified'),
        ('accepted', 'Accepted by Hospital'),
        ('rejected', 'Rejected by Hospital'),
        ('attended', 'Medical Team On-Site'),
        ('received', 'Patient Received at Hospital'),
        ('treatment', 'Treatment Started'),
        ('closed', 'Case Closed'),
    ]
    
    bus = models.ForeignKey(Bus, on_delete=models.SET_NULL, null=True, blank=True)
    passenger_name = models.CharField(max_length=100)
    passenger_age = models.IntegerField(null=True, blank=True)
    passenger_gender = models.CharField(max_length=10, choices=[('M', 'Male'), ('F', 'Female'), ('O', 'Other')], null=True, blank=True)
    emergency_type = models.CharField(max_length=100)
    description = models.TextField()
    latitude = models.FloatField()
    longitude = models.FloatField()
    
    hospital_notified = models.ForeignKey(Hospital, on_delete=models.SET_NULL, null=True, blank=True, related_name='emergencies')
    status = models.CharField(max_length=30, choices=STATUS_CHOICES, default='pending')
    
    # Timestamps for analytics
    created_at = models.DateTimeField(auto_now_add=True)
    accepted_at = models.DateTimeField(null=True, blank=True)
    attended_at = models.DateTimeField(null=True, blank=True)
    received_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    # Allow bus staff to update condition
    condition_update = models.TextField(null=True, blank=True)
    
    # Track hospitals that rejected this request
    rejected_by = models.ManyToManyField(Hospital, related_name='rejected_emergencies', blank=True)

    def __str__(self):
        return f"Emergency {self.id} - {self.bus.bus_number if self.bus else 'No Bus'} - {self.passenger_name}"

class EmergencyLog(models.Model):
    emergency = models.ForeignKey(Emergency, on_delete=models.CASCADE, related_name='logs')
    action = models.CharField(max_length=200)
    performed_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    details = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"Log for Emergency {self.emergency.id} - {self.action}"
