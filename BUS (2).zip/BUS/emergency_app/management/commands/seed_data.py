import os
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from emergency_app.models import Hospital, Bus

User = get_user_model()

class Command(BaseCommand):
    help = 'Seeds the database with sample data for BEMS'

    def handle(self, *args, **kwargs):
        self.stdout.write('Seeding data...')

        # 1. Create System Administrator
        admin_user, created = User.objects.get_or_create(
            username='system_admin',
            defaults={
                'role': User.ADMIN,
                'email': 'sysadmin@bems.com',
                'is_staff': True,
                'is_superuser': True,
            }
        )
        if created:
            admin_user.set_password('admin123')
            admin_user.save()
            self.stdout.write(self.style.SUCCESS(f'Created System Admin: {admin_user.username} (pw: admin123)'))

        # 2. Create Buses
        buses_data = [
            {'bus_number': 'KA-01-F-1234', 'route': 'Majestic - Silk Board', 'driver': 'Rajesh Kumar', 'conductor': 'Suresh Reddy'},
            {'bus_number': 'KA-02-B-5678', 'route': 'Indiranagar - Whitefield', 'driver': 'Amit Sharma', 'conductor': 'Vijay Gowda'},
            {'bus_number': 'KA-03-A-9101', 'route': 'Koramangala - Hebbal', 'driver': 'Ravi Kumar', 'conductor': 'Naveen Singh'},
        ]
        
        buses_objs = []
        for b in buses_data:
            obj, created = Bus.objects.get_or_create(
                bus_number=b['bus_number'],
                defaults={
                    'route_name': b['route'],
                    'driver_name': b['driver'],
                    'conductor_name': b['conductor'],
                }
            )
            buses_objs.append(obj)
            if created:
                self.stdout.write(f'Created Bus: {obj.bus_number}')

        # 3. Create Hospitals
        hospitals_data = [
            {'name': 'St. Mary\'s General Hospital', 'address': '123 MG Road, Central Area', 'lat': 12.9716, 'lng': 77.5946, 'email': 'stmarys@hospital.com', 'cap': 25, 'spec': 'Cardiology, ICU, Trauma'},
            {'name': 'City Life Speciality Clinic', 'address': '45 Indiranagar, East Side', 'lat': 12.9784, 'lng': 77.6408, 'email': 'citylife@hospital.com', 'cap': 12, 'spec': 'General, Pediatrics'},
            {'name': 'Metro Health Institute', 'address': '88 Koramangala, South West', 'lat': 12.9352, 'lng': 77.6245, 'email': 'metro@hospital.com', 'cap': 40, 'spec': 'Neurology, Cardiology, ICU'},
        ]

        hospital_objs = []
        for h in hospitals_data:
            obj, created = Hospital.objects.get_or_create(
                name=h['name'],
                defaults={
                    'address': h['address'],
                    'latitude': h['lat'],
                    'longitude': h['lng'],
                    'email': h['email'],
                    'emergency_capacity': h['cap'],
                    'specialties': h['spec'],
                    'is_active': True,
                    'is_enabled': True,
                    'contact_number': '+91 80 1234 5678'
                }
            )
            hospital_objs.append(obj)
            if created:
                self.stdout.write(f'Created Hospital: {obj.name}')

        # 4. Create Role-specific users
        # Bus Staff
        staff_user, created = User.objects.get_or_create(
            username='bus_staff',
            defaults={
                'role': User.BUS_STAFF,
                'email': 'staff@busco.com',
                'assigned_bus': buses_objs[0],
                'contact_number': '+91 9900112233'
            }
        )
        if created:
            staff_user.set_password('staff123')
            staff_user.save()
            self.stdout.write(self.style.SUCCESS('Created Bus Staff: bus_staff'))

        # Hospital Staff
        h_staff, created = User.objects.get_or_create(
            username='hospital_staff',
            defaults={
                'role': User.HOSPITAL_STAFF,
                'email': 'care@stmarys.com',
                'assigned_hospital': hospital_objs[0],
                'contact_number': '+91 9876543210'
            }
        )
        if created:
            h_staff.set_password('hospital123')
            h_staff.save()
            self.stdout.write(self.style.SUCCESS('Created Hospital Staff: hospital_staff'))

        self.stdout.write(self.style.SUCCESS('Seeding completed successfully!'))
