# Initialized directory
