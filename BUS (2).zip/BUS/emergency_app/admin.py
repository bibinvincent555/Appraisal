from django.contrib import admin
from .models import CustomUser, Hospital, Bus, Emergency, EmergencyLog

@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('username', 'role', 'assigned_hospital', 'assigned_bus', 'is_staff')
    list_filter = ('role', 'is_staff')

@admin.register(Hospital)
class HospitalAdmin(admin.ModelAdmin):
    list_display = ('name', 'address', 'contact_number', 'is_active', 'is_enabled')
    list_filter = ('is_active', 'is_enabled')

@admin.register(Bus)
class BusAdmin(admin.ModelAdmin):
    list_display = ('bus_number', 'route_name', 'driver_name', 'conductor_name', 'is_active')
    list_filter = ('is_active',)

@admin.register(Emergency)
class EmergencyAdmin(admin.ModelAdmin):
    list_display = ('id', 'bus', 'passenger_name', 'emergency_type', 'status', 'created_at')
    list_filter = ('status', 'emergency_type')

@admin.register(EmergencyLog)
class EmergencyLogAdmin(admin.ModelAdmin):
    list_display = ('emergency', 'action', 'performed_by', 'timestamp')
    list_filter = ('action',)
