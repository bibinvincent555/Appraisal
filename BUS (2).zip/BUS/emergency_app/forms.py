from django import forms
from .models import Emergency, Bus, Hospital, CustomUser

class EmergencyReportForm(forms.ModelForm):
    class Meta:
        model = Emergency
        fields = ['bus', 'passenger_name', 'passenger_age', 'passenger_gender', 'emergency_type', 'description', 'latitude', 'longitude']
        widgets = {
            'bus': forms.Select(attrs={'class': 'form-select'}),
            'passenger_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Passenger Name'}),
            'passenger_age': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Enter Age'}),
            'passenger_gender': forms.Select(attrs={'class': 'form-select'}),
            'emergency_type': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Heart problem, Injury, etc.'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Condition details...'}),
            'latitude': forms.NumberInput(attrs={'class': 'form-control', 'step': 'any', 'id': 'id_lat'}),
            'longitude': forms.NumberInput(attrs={'class': 'form-control', 'step': 'any', 'id': 'id_lng'}),
        }

class HospitalForm(forms.ModelForm):
    class Meta:
        model = Hospital
        fields = ['name', 'address', 'contact_number', 'email', 'latitude', 'longitude', 'emergency_capacity', 'specialties', 'is_enabled']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'contact_number': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'latitude': forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'}),
            'longitude': forms.NumberInput(attrs={'class': 'form-control', 'step': 'any'}),
            'emergency_capacity': forms.NumberInput(attrs={'class': 'form-control'}),
            'specialties': forms.TextInput(attrs={'class': 'form-control'}),
            'is_enabled': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

class BusForm(forms.ModelForm):
    class Meta:
        model = Bus
        fields = ['bus_number', 'route_name', 'driver_name', 'conductor_name', 'is_active']
        widgets = {
            'bus_number': forms.TextInput(attrs={'class': 'form-control'}),
            'route_name': forms.TextInput(attrs={'class': 'form-control'}),
            'driver_name': forms.TextInput(attrs={'class': 'form-control'}),
            'conductor_name': forms.TextInput(attrs={'class': 'form-control'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'role', 'first_name', 'last_name', 'contact_number']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'role': forms.Select(attrs={'class': 'form-select'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'contact_number': forms.TextInput(attrs={'class': 'form-control'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['role'].choices = [
            (CustomUser.BUS_STAFF, 'Bus Staff (Driver/Conductor)'),
            (CustomUser.HOSPITAL_STAFF, 'Hospital Staff'),
        ]


    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()
        return user

class UserAssignmentForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ['role', 'assigned_hospital', 'assigned_bus', 'is_active']
        widgets = {
            'role': forms.Select(attrs={'class': 'form-select'}),
            'assigned_hospital': forms.Select(attrs={'class': 'form-select'}),
            'assigned_bus': forms.Select(attrs={'class': 'form-select'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'})
        }
