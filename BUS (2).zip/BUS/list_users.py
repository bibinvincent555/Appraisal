
import os
import django
import sys

# Set up Django environment
sys.path.append(os.getcwd())
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'bems_project.settings')
django.setup()

from emergency_app.models import CustomUser

def list_users():
    users = CustomUser.objects.all()
    with open('users_data.txt', 'w', encoding='utf-8') as f:
        f.write("-" * 110 + "\n")
        f.write(f"{'ID':<4} | {'Username':<15} | {'Email':<25} | {'Role':<15} | {'Superuser':<10} | {'Hospital':<20} | {'Bus':<15}\n")
        f.write("-" * 110 + "\n")
        for user in users:
            hospital = str(user.assigned_hospital) if user.assigned_hospital else 'N/A'
            bus = str(user.assigned_bus.bus_number) if user.assigned_bus else 'N/A'
            f.write(f"{user.id:<4} | {user.username:<15} | {user.email:<25} | {user.role:<15} | {str(user.is_superuser):<10} | {hospital:<20} | {bus:<15}\n")
        f.write("-" * 110 + "\n")
    print("User list written to users_data.txt")

if __name__ == "__main__":
    list_users()
