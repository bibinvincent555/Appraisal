# BEMS - Bus Emergency Medical System

BEMS is a sophisticated, real-time emergency medical response platform designed for urban transit networks, optimizing passenger safety through automated hospital routing and role-based coordination.

## 🚀 Key Modules & Functionalities

### 1. System Administrator
- **Comprehensive Infrastructure Control**: CRUD management for Hospital facilities, Bus units, and User accounts.
- **Entity Lifecycle**: Toggle hospital readiness, manage bus routes, and assign staff pairing.
- **Global Monitor**: Live system-wide stream of all emergency incidents and response performance.

### 2. Bus Staff (Driver / Conductor)
- **Rapid Alert System**: Instant GPS-based emergency reporting with nature-of-incident details.
- **Condition Tracking**: Real-time updates for hospital teams if passenger status changes on-site.
- **Unit Hub**: Dedicated dashboard for monitoring incidents specifically assigned to their transit unit.

### 3. Hospital Staff
- **Priority Alert Terminal**: Monitor incoming alerts with passenger criticality and bus location.
- **Resource Management**: Accept or Reject requests based on current bed capacity or specialist availability.
- **Life-Saving Lifecycle**: Direct status updates (Accepted -> Attended -> Received -> Treating -> Resolved).

## 🛠️ Technology Stack
- **Framework**: Django (Python 3.x)
- **Mapping**: Leaflet.js + OpenStreetMap (No API keys required)
- **Styling**: Vanilla CSS3 + Font Awesome 6 + Modern Icons
- **Database**: SQLite (ACID compliant)

## 🏗️ Quick Start
1. **Initialize Environment**: `pip install django`
2. **Schema Migration**: `python manage.py makemigrations; python manage.py migrate`
3. **Populate Network**: `python manage.py seed_data`
4. **Boot Up**: `python manage.py runserver`

## 🔐 Verified Demo Credentials
| Role | Username | Password |
| :--- | :------- | :------- |
| **System Admin** | `system_admin` | `admin123` |
| **Bus Staff** | `bus_staff` | `staff123` |
| **Hospital Staff** | `hospital_staff` | `hospital123` |

---
*BEMS: Bridging the gap between transit emergencies and medical response.*
