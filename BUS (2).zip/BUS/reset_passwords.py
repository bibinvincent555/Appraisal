import os
import django
import sys

# Set up Django environment
sys.path.append(os.getcwd())
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'bems_project.settings')
django.setup()

from emergency_app.models import CustomUser

def reset_all_passwords():
    new_password = "password123"
    users = CustomUser.objects.all()
    print(f"Resetting passwords for {len(users)} users...")
    
    for user in users:
        user.set_password(new_password)
        user.save()
        print(f"Updated password for: {user.username}")
    
    print(f"\nAll passwords have been reset to: {new_password}")

if __name__ == "__main__":
    reset_all_passwords()
